<?
// THIS FILE IS FOR UPGRADING FROM 0.9.3 ONLY
include 'config.inc';

$con = mysql_connect($dbserver,$dbuser,$dbpass);
mysql_select_db($dbname, $con);

if ($_REQUEST["step"]==2) {

	echo "Upgrading database... ";
	mysql_query("ALTER TABLE `aircraft` ADD  `fuelunit` CHAR( 25 ) NOT NULL");
	mysql_query("ALTER TABLE `users` CHANGE `password` `password` CHAR( 32 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL");
	// reset passwords
	mysql_query("UPDATE `users` SET `password` =  '" . md5($_REQUEST['newpass']) . "' WHERE `users`.`id` = " . $_REQUEST['user'] . ";");
	echo "Done.<br>\n";

	echo "Protecting files... ";
	chmod("setup.php", 0000);
	chmod("upgrade.php", 0000);
	echo "Done<br><br>\n";

	echo "Upgrade complete.  Visit the <a href=\"admin.php\">admin area</a> or <a href=\"index.php\">main interface</a>.";
	
} else {

	echo "Due to a change in the way passwords are stored in the database, reset of passwords for ALL user accounts is required.<br><br>\n";
	echo "Here you will reset the password for an administrator account, then you will be able to login after upgrading.  The administrator\n";
	echo "will then need to reset passwords for all other users.<br><br>";

	echo "<form method=\"post\" action=\"upgrade.php\">\n";
	echo "<input type=\"hidden\" name=\"step\" value=\"2\">\n";
	echo "<select name=\"user\">";
	$userquery = mysql_query("SELECT * FROM `users` WHERE `superuser` = 1");
	while ($userlist = mysql_fetch_assoc($userquery)) {
		echo "<option value=\"" . $userlist['id'] . "\">" . $userlist['username'] . " - " . $userlist['name'] . "</option>\n";
	}
	echo "</select><br>\n";
	echo "New Password: <input type=\"password\" name=\"newpass\">";
	echo "<input type=\"submit\">\n";
	echo "</form>\n";

}

?>