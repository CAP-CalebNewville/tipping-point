<?
// THIS FILE IS FOR UPGRADING FROM 0.9.2 OR EARLIER
include 'config.inc';

$con = mysql_connect($dbserver,$dbuser,$dbpass);
mysql_select_db($dbname, $con);

echo "Upgrading database... ";
mysql_query("INSERT INTO `configuration` (`item`, `value`) VALUES ('update_check', '" . time() . "'), ('update_version', '0.9.3')");
echo "Done.<br>\n";

echo "Protecting files... ";
chmod("setup.php", 0000);
chmod("upgrade.php", 0000);
echo "Done<br><br>\n";

echo "Upgrade complete.  Visit the <a href=\"admin.php\">admin area</a> or <a href=\"index.php\">main interface</a>.";

?>